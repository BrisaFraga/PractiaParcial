export const peliculas = [
    {
        "id": 3,
        "titulo": "El caballero de la noche",
        "director": "Christopher Nolan",
        "genero": "Acción",
        "duracion": 130,
        "idClasificacion": 3
    },
    {
        "id": 2,
        "titulo": "El padrino",
        "director": "Francis Ford Coppola",
        "genero": "Drama",
        "duracion": 122,
        "idClasificacion": 2
    }, {
        "id": 4,
        "titulo": "El señor de los anillos: El retorno del rey",
        "director": "Peter Jackson",
        "genero": "Fantasía",
        "duracion": 138,
        "idClasificacion": 4
    },
    {
        "id": 10,
        "titulo": "El silencio de los inocentes",
        "director": "Jonathan Demme",
        "genero": "Crimen",
        "duracion": 139,
        "idClasificacion": 5
    }, {
        "id": 6,
        "titulo": "Forrest Gump",
        "director": "Robert Zemeckis",
        "genero": "Drama",
        "duracion": 154,
        "idClasificacion": 1
    },
    {
        "id": 9,
        "titulo": "Interestelar",
        "director": "Christopher Nolan",
        "genero": "Ciencia ficción",
        "duracion": 131,
        "idClasificacion": 4
    },
    {
        "id": 8,
        "titulo": "Matrix",
        "director": "Lana Wachowski, Lilly Wachowski",
        "genero": "Acción",
        "duracion": 123,
        "idClasificacion": 3
    }, {
        "id": 7,
        "titulo": "Origen",
        "director": "Christopher Nolan",
        "genero": "Acción",
        "duracion": 115,
        "idClasificacion": 2
    }, {
        "id": 5,
        "titulo": "Pulp Fiction",
        "director": "Quentin Tarantino",
        "genero": "Crimen",
        "duracion": 146,
        "idClasificacion": 5
    },
    {
        "id": 1,
        "titulo": "Sueño de fuga",
        "director": "Frank Darabont",
        "genero": "Drama",
        "duracion": 114,
        "idClasificacion": 1
    }
]