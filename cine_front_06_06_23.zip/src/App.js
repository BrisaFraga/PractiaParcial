import logo from './logo.svg';
import './App.css';
import Peliculas from './components/Peliculas';

function App() {
  return (
    <div className="container">
      <Peliculas/>
    </div>
  );
}

export default App;
